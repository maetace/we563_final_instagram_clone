import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';
// import 'package:collection/collection.dart';

import '../models/mock_user.dart';
import 'mock_user_data.dart';
import 'account_service.dart';

class AccountServiceMock extends GetxService implements AccountService {
  final _secure = const FlutterSecureStorage();

  static const _keyUid = 'uid';
  static const _keyToken = 'token';

  @override
  Future<void> logIn(String username, String password) async {
    await 1.delay(); // simulate API call

    final user = users.firstWhereOrNull(
      (u) => u.username == username && u.password == password && u.status == UserStatus.active,
    );

    if (user == null) {
      throw 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง';
    }

    await _secure.write(key: _keyUid, value: user.uid);
    await _secure.write(key: _keyToken, value: 'mock_token');
  }

  @override
  Future<void> signUp(
    String username,
    String password,
    String? email,
    String? mobile,
    String? avatar,
    String? birthday,
  ) async {
    await 1.delay(); // simulate API call

    final exists = users.any((u) => u.username == username || u.email == email);
    if (exists) throw 'มีผู้ใช้นี้อยู่แล้ว';

    // ใน mock นี้จะไม่เพิ่ม user จริง ๆ แค่จำลองการลงทะเบียนสำเร็จ
    await _secure.write(key: _keyUid, value: 'new_user_uid');
    await _secure.write(key: _keyToken, value: 'mock_token');
  }

  @override
  Future<bool> isLoggedIn() async {
    final token = await _secure.read(key: _keyToken);
    return token != null;
  }

  @override
  Future<void> logOut() async {
    await _secure.delete(key: _keyUid);
    await _secure.delete(key: _keyToken);
  }

  Future<User?> getCurrentUser() async {
    final uid = await _secure.read(key: _keyUid);
    return users.firstWhereOrNull((u) => u.uid == uid);
  }
}
