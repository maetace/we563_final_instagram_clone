import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:logger/logger.dart';

class UserSessionService {
  static const _keyUid = 'uid';
  static const _keyToken = 'token';

  final _secure = const FlutterSecureStorage();

  // Save
  Future<void> saveSession({required String uid, required String token}) async {
    await _secure.write(key: _keyUid, value: uid);
    await _secure.write(key: _keyToken, value: token);
    Logger().i('💾 Saved session: uid=$uid, token=$token');
  }

  // Load
  Future<String?> getUid() => _secure.read(key: _keyUid);
  Future<String?> getToken() => _secure.read(key: _keyToken);

  // Clear
  Future<void> clearSession() async {
    await _secure.delete(key: _keyUid);
    await _secure.delete(key: _keyToken);
  }
}
