import 'package:collection/collection.dart';

import '../models/mock_user.dart';
import 'mock_user_data.dart';

class UserService {
  List<User> getAllUsers() => users;

  User? getUserByUsername(String username) {
    return users.firstWhereOrNull((user) => user.username == username);
  }

  User? getUserByEmail(String email) {
    return users.firstWhereOrNull((user) => user.email == email);
  }

  User? getUserByUid(String uid) {
    return users.firstWhereOrNull((user) => user.uid == uid);
  }

  User? authenticate(String username, String password) {
    return users.firstWhereOrNull(
      (user) => user.username == username && user.password == password && user.status == UserStatus.active,
    );
  }
}
