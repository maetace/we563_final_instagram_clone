enum Gender { male, female, other }

enum UserStatus { active, inactive, pending, deleted, banned }

class User {
  final String uid;
  final String username;
  final String password;
  final String email;
  final String mobile;
  final String avatar;
  final String fullname;
  final DateTime birthday;
  final Gender gender;
  final DateTime created;
  final DateTime updated;
  final UserStatus status;

  const User({
    required this.uid,
    required this.username,
    required this.password,
    required this.email,
    required this.mobile,
    required this.avatar,
    required this.fullname,
    required this.birthday,
    required this.gender,
    required this.created,
    required this.updated,
    required this.status,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      uid: json['uid'],
      username: json['username'],
      password: json['password'],
      email: json['email'],
      mobile: json['mobile'],
      avatar: json['avatar'],
      fullname: json['fullname'],
      birthday: DateTime.parse(json['birthday']),
      gender: Gender.values.firstWhere((e) => e.name == json['gender']),
      created: DateTime.parse(json['created']),
      updated: DateTime.parse(json['updated']),
      status: UserStatus.values.firstWhere((e) => e.name == json['status']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'uid': uid,
      'username': username,
      'password': password,
      'email': email,
      'mobile': mobile,
      'avatar': avatar,
      'fullname': fullname,
      'birthday': birthday.toIso8601String(),
      'gender': gender.name,
      'created': created.toIso8601String(),
      'updated': updated.toIso8601String(),
      'status': status.name,
    };
  }
}
