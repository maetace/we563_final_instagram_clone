class CurrentUser {
  final String uid;
  final String username;
  final String fullname;
  final String avatar;

  const CurrentUser({required this.uid, required this.username, required this.fullname, required this.avatar});

  factory CurrentUser.fromJson(Map<String, dynamic> json) {
    return CurrentUser(
      uid: json['uid'],
      username: json['username'],
      fullname: json['fullname'],
      avatar: json['avatar'],
    );
  }

  Map<String, dynamic> toJson() {
    return {'uid': uid, 'username': username, 'fullname': fullname, 'avatar': avatar};
  }
}
