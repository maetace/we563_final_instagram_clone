import 'package:flutter/material.dart';

const String fontFamily = 'roboto';

final TextTheme appTextTheme = TextTheme(
  displayLarge: TextStyle(fontSize: 57, fontWeight: FontWeight.normal, fontFamily: fontFamily),
  displayMedium: TextStyle(fontSize: 45, fontWeight: FontWeight.normal, fontFamily: fontFamily),
  displaySmall: TextStyle(fontSize: 36, fontWeight: FontWeight.normal, fontFamily: fontFamily),
  headlineLarge: TextStyle(fontSize: 32, fontWeight: FontWeight.normal, fontFamily: fontFamily),
  headlineMedium: TextStyle(fontSize: 28, fontWeight: FontWeight.normal, fontFamily: fontFamily),
  headlineSmall: TextStyle(fontSize: 24, fontWeight: FontWeight.normal, fontFamily: fontFamily),
  titleLarge: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, fontFamily: fontFamily),
  titleMedium: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, fontFamily: fontFamily),
  titleSmall: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, fontFamily: fontFamily),
  bodyLarge: TextStyle(fontSize: 16, fontWeight: FontWeight.normal, fontFamily: fontFamily),
  bodyMedium: TextStyle(fontSize: 14, fontWeight: FontWeight.normal, fontFamily: fontFamily),
  bodySmall: TextStyle(fontSize: 12, fontWeight: FontWeight.normal, fontFamily: fontFamily),
  labelLarge: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, fontFamily: fontFamily),
  labelMedium: TextStyle(fontSize: 12, fontWeight: FontWeight.w500, fontFamily: fontFamily),
  labelSmall: TextStyle(fontSize: 11, fontWeight: FontWeight.w500, fontFamily: fontFamily),
);
